import styles from "./settings.module.css";

const Home = () => {
  return (
    <div className={styles.hello}>
      <p>Настройки</p>
    </div>
  );
};

export default Home;
