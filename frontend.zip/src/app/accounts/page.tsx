import styles from "./accounts.module.css";

const Accounts = () => {
  return (
    <div className={styles.hello}>
      <p>Аккаунты</p>
    </div>
  );
};

export default Accounts;
