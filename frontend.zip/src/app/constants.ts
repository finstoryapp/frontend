export const EXPENSE_MAX_AMOUNT = 100000000;
export const russianMonths = [
  "Январь",
  "Февраль",
  "Март",
  "Апрель",
  "Май",
  "Июнь",
  "Июль",
  "Август",
  "Сентябрь",
  "Октябрь",
  "Ноябрь",
  "Декабрь",
];
export const russianDayNames = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];
