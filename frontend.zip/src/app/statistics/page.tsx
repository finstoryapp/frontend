import styles from "./statistics.module.css";

const Home = () => {
  return (
    <div className={styles.hello}>
      <p>Статистика</p>
    </div>
  );
};

export default Home;
