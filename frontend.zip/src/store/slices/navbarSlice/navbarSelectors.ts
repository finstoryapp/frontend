import { RootState } from "../../store";

export const page = (state: RootState) => state.navbar.page;
