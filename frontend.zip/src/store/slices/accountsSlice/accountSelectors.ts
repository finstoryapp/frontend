import { RootState } from "@/store/store";
export const accountState = (state: RootState) => state.accounts;
