import { RootState } from "@/store/store";

export const expensesNavbarState = (state: RootState) => state.expensesNavbar;
