import { RootState } from "@/store/store";

export const expensesState = (state: RootState) => state.expenses;
