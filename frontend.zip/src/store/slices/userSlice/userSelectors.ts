import { RootState } from "@/store/store";

export const userState = (state: RootState) => state.user;
