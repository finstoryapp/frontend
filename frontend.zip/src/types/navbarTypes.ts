export interface Navbar {
  page: "home" | "accounts" | "statistics" | "settings";
}
