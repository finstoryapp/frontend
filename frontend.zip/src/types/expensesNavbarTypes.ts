export interface ExpensesNavbarState {
  year: number;
  month: number;
  isCurrentMonth: boolean;
}
