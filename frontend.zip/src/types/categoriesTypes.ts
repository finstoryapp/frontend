export interface ICategory {
  name: string;
  color: string;
}
