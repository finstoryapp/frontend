import HomeIcon from "../../../public/icons/home.svg";
import AccountsIcon from "../../../public/icons/accounts.svg";
import StatisticsIcon from "../../../public/icons/statistics.svg";
import SettingsIcon from "../../../public/icons/settings.svg";

export const paths = [
  { path: "/", state: "home", label: "Домашняя", icon: HomeIcon },
  { path: "/accounts", state: "accounts", label: "Счета", icon: AccountsIcon },
  {
    path: "/statistics",
    state: "statistics",
    label: "Статистика",
    icon: StatisticsIcon,
  },
  {
    path: "/settings",
    state: "settings",
    label: "Настройки",
    icon: SettingsIcon,
  },
];
